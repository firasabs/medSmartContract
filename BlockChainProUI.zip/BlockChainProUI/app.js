import{uploadToIPFS} from './ipfs.js'
// MetaMask connection and contract setup
async function connectToMetaMask() {
    if (typeof window.ethereum !== 'undefined') {
        try {
            // Request account access
            await window.ethereum.request({method: 'eth_requestAccounts'});

            // Initialize the ethers provider
            const provider = new ethers.providers.Web3Provider(window.ethereum);
            const signer = provider.getSigner();
            console.log('Connected to MetaMask');

            // Update UI with wallet address
            const walletAddress = await signer.getAddress();
            document.getElementById("statusMessage").innerText = `Connected wallet: ${walletAddress}`;

            return { provider, signer };
        } catch (error) {
            console.error('Error connecting to MetaMask:', error);
        }
    } else {
        alert('MetaMask is not installed.');
    }
}

// Smart contract ABI and address
const contractABI = [
	{
		"inputs": [],
		"stateMutability": "nonpayable",
		"type": "constructor"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "address",
				"name": "admin",
				"type": "address"
			}
		],
		"name": "AdminAdded",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "address",
				"name": "admin",
				"type": "address"
			}
		],
		"name": "AdminRemoved",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "string",
				"name": "id",
				"type": "string"
			},
			{
				"indexed": false,
				"internalType": "string",
				"name": "name",
				"type": "string"
			},
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "medicineAmount",
				"type": "uint256"
			},
			{
				"indexed": false,
				"internalType": "string",
				"name": "expiryDate",
				"type": "string"
			},
			{
				"indexed": false,
				"internalType": "string",
				"name": "ipfsHash",
				"type": "string"
			}
		],
		"name": "MedicineAdded",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "string",
				"name": "id",
				"type": "string"
			},
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "newMedicineAmount",
				"type": "uint256"
			}
		],
		"name": "MedicineAmountUpdated",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "string",
				"name": "id",
				"type": "string"
			}
		],
		"name": "MedicineRemoved",
		"type": "event"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "_admin",
				"type": "address"
			}
		],
		"name": "addAdmin",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "string",
				"name": "_id",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_name",
				"type": "string"
			},
			{
				"internalType": "uint256",
				"name": "_medicineAmount",
				"type": "uint256"
			},
			{
				"internalType": "string",
				"name": "_expiryDate",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_ipfsHash",
				"type": "string"
			}
		],
		"name": "addMedicine",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "",
				"type": "address"
			}
		],
		"name": "admins",
		"outputs": [
			{
				"internalType": "bool",
				"name": "",
				"type": "bool"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "getHash",
		"outputs": [
			{
				"internalType": "string",
				"name": "",
				"type": "string"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "string",
				"name": "_id",
				"type": "string"
			}
		],
		"name": "getMedicine",
		"outputs": [
			{
				"internalType": "string",
				"name": "name",
				"type": "string"
			},
			{
				"internalType": "uint256",
				"name": "medicineAmount",
				"type": "uint256"
			},
			{
				"internalType": "string",
				"name": "expiryDate",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "ipfsHash",
				"type": "string"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "owner",
		"outputs": [
			{
				"internalType": "address",
				"name": "",
				"type": "address"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "_admin",
				"type": "address"
			}
		],
		"name": "removeAdmin",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "string",
				"name": "_id",
				"type": "string"
			}
		],
		"name": "removeMedicine",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "string",
				"name": "x",
				"type": "string"
			}
		],
		"name": "sendHash",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "string",
				"name": "_id",
				"type": "string"
			},
			{
				"internalType": "uint256",
				"name": "_amountToSubtract",
				"type": "uint256"
			}
		],
		"name": "subtractMedicineAmount",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	}
];

const contractAddress = "0x5b3c4872841c18bed87515b26c674dd3b28b9c64";

// Load the contract
async function loadContract() {
    const { signer } = await connectToMetaMask();
    const contract = new ethers.Contract(contractAddress, contractABI, signer);
    return contract;
}

// Event listener for adding medicine
document.getElementById('addMedicineButton').addEventListener('click', async () => {
    try {
        // Load the contract instance
        const contract = await loadContract();

        // Fetch the values from the input fields
        const medicineId = document.getElementById('medicineId').value;
        const medicineName = document.getElementById('medicineName').value;
        const medicineAmount = document.getElementById('medicineAmount').value;
        const expiryDate = document.getElementById('expiryDate').value;
        const medicineDocument = document.getElementById('medicineDocument').files[0];

        // Log the values to ensure they are not null/undefined
        console.log("Medicine ID:", medicineId);
        console.log("Medicine Name:", medicineName);
        console.log("Medicine Amount:", medicineAmount);
        console.log("Expiry Date:", expiryDate);
        console.log("Selected Document:", medicineDocument);

        // Check if any of the fields are missing
        if (!medicineId || !medicineName || !medicineAmount || !expiryDate || !medicineDocument) {
            console.error('One or more input fields are missing.');
            document.getElementById("statusMessage").innerText = 'Please fill in all fields and select a document.';
            return;
        }

        // Upload the document to IPFS
        const ipfsHash = await uploadToIPFS(medicineDocument);
        //const ipfsHash = "07026970515F99BAE495781F303D6F5B15BD85E6B212D617C571DA685B4FA1CF8";
		console.log("IPFS Hash:", ipfsHash);  // Ensure the hash is being generated

        // If IPFS hash is valid, proceed with the transaction
        const tx = await contract.addMedicine(medicineId, medicineName, medicineAmount, expiryDate, ipfsHash);
        await tx.wait();

        document.getElementById("statusMessage").innerText = 'Medicine added successfully!';
    } catch (error) {
        document.getElementById("statusMessage").innerText = `Error : ${error.message}`;
        console.error("Error adding medicine:", error);
    }
});



// Event listener for getting medicine details
document.getElementById('getMedicineButton').addEventListener('click', async () => {
    try {
        const contract = await loadContract();

        const medicineId = document.getElementById('getMedicineId').value;
		const medicineInfo = await contract.getMedicine(medicineId);
        const { name, amount, expiryDate, documentHash } = medicineInfo;
    	const ipfsLink = `https://ipfs.io/ipfs/${documentHash}`;
		//const ipfsLink = 'https://ipfs.io/ipfs/QmVtSVzyXNtDFUMnEnuM5HmvZ9AcLiJFVyo8ubv2YCXXrf?filename=%D7%9C%D7%95%D7%96.docx'
		    // Display the medicine details and document link
		document.getElementById('medicineInfo').innerHTML = `
			<p>Medicine Name: ${name}</p>
			<p>Amount: ${amount}</p>
			<p>Expiry Date: ${expiryDate}</p>
			<p>Document: <a href="${ipfsLink}" target="_blank">View Document</a></p>
		`;
    } catch (error) {
        document.getElementById("medicineInfo").innerText = `Error: ${error.message}`;
    }
});


